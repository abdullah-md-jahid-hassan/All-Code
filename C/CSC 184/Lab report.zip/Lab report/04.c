#include <stdio.h>
int main ()
{
  printf("Enter total Distance: "); float d,f;scanf("%f",&d);
  printf("Ender total Fule Consumtion: "); scanf("%f",&f);
  printf("Avarage Fule Consumtion is %0.2f l/km",f/d);
  return 0;
}
